Citizen.CreateThread(function()
		RequestIpl("sm_smugdlc_interior_placement")     --Already loaded in iplLoader
		RequestIpl("sm_smugdlc_interior_placement_interior_0_smugdlc_int_01_milo_")
		RequestIpl("xm_x17dlc_int_02")
		RequestIpl("xm_x17dlc_int_placement")
		RequestIpl("xm_x17dlc_int_placement_interior_0_x17dlc_int_base_ent_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_10_x17dlc_int_tun_straight_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_11_x17dlc_int_tun_slope_flat_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_12_x17dlc_int_tun_flat_slope_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_13_x17dlc_int_tun_30d_r_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_14_x17dlc_int_tun_30d_l_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_15_x17dlc_int_tun_straight_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_16_x17dlc_int_tun_straight_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_17_x17dlc_int_tun_slope_flat_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_18_x17dlc_int_tun_slope_flat_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_19_x17dlc_int_tun_flat_slope_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_1_x17dlc_int_base_loop_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_20_x17dlc_int_tun_flat_slope_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_21_x17dlc_int_tun_30d_r_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_22_x17dlc_int_tun_30d_r_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_23_x17dlc_int_tun_30d_r_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_24_x17dlc_int_tun_30d_r_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_25_x17dlc_int_tun_30d_l_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_26_x17dlc_int_tun_30d_l_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_27_x17dlc_int_tun_30d_l_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_28_x17dlc_int_tun_30d_l_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_29_x17dlc_int_tun_30d_l_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_2_x17dlc_int_bse_tun_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_30_v_apart_midspaz_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_31_v_studio_lo_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_32_v_garagem_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_33_x17dlc_int_02_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_34_x17dlc_int_lab_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_35_x17dlc_int_tun_entry_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_3_x17dlc_int_base_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_4_x17dlc_int_facility_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_5_x17dlc_int_facility2_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_6_x17dlc_int_silo_01_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_7_x17dlc_int_silo_02_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_8_x17dlc_int_sub_milo_")
		RequestIpl("xm_x17dlc_int_placement_interior_9_x17dlc_int_01_milo_")
		RequestIpl("xm_x17dlc_int_placement_strm_0")
		RequestIpl("xm_bunkerentrance_door")
		RequestIpl("xm_hatch_01_cutscene")
		RequestIpl("xm_hatch_02_cutscene")
		RequestIpl("xm_hatch_03_cutscene")
		RequestIpl("xm_hatch_04_cutscene")
		RequestIpl("xm_hatch_06_cutscene")
		RequestIpl("xm_hatch_07_cutscene")
		RequestIpl("xm_hatch_08_cutscene")
		RequestIpl("xm_hatch_09_cutscene")
		RequestIpl("xm_hatch_10_cutscene")
		RequestIpl("xm_hatch_closed")
		RequestIpl("xm_hatches_terrain")
		RequestIpl("xm_hatches_terrain_lod")
		RequestIpl("xm_mpchristmasadditions")
		RequestIpl("xm_siloentranceclosed_x17")
		
		
		--RequestIpl("xm_siloentranceclosed_x17")
		
--[[
	RequestIpl("sm_smugdlc_interior_placement")
	RequestIpl("sm_smugdlc_interior_placement_interior_0_smugdlc_int_01_milo_")
	RequestIpl("xm_x17dlc_int_placement")

	RequestIpl("xm_x17dlc_int_placement_interior_0_x17dlc_int_base_ent_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_1_x17dlc_int_base_loop_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_2_x17dlc_int_bse_tun_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_3_x17dlc_int_base_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_4_x17dlc_int_facility_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_5_x17dlc_int_facility2_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_6_x17dlc_int_silo_01_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_7_x17dlc_int_silo_02_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_8_x17dlc_int_sub_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_9_x17dlc_int_01_milo_")

	RequestIpl("xm_x17dlc_int_placement_interior_10_x17dlc_int_tun_straight_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_11_x17dlc_int_tun_slope_flat_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_12_x17dlc_int_tun_flat_slope_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_13_x17dlc_int_tun_30d_r_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_14_x17dlc_int_tun_30d_l_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_15_x17dlc_int_tun_straight_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_16_x17dlc_int_tun_straight_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_17_x17dlc_int_tun_slope_flat_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_18_x17dlc_int_tun_slope_flat_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_19_x17dlc_int_tun_flat_slope_milo_")

	RequestIpl("xm_x17dlc_int_placement_interior_20_x17dlc_int_tun_flat_slope_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_21_x17dlc_int_tun_30d_r_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_22_x17dlc_int_tun_30d_r_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_23_x17dlc_int_tun_30d_r_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_24_x17dlc_int_tun_30d_r_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_25_x17dlc_int_tun_30d_l_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_26_x17dlc_int_tun_30d_l_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_27_x17dlc_int_tun_30d_l_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_28_x17dlc_int_tun_30d_l_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_29_x17dlc_int_tun_30d_l_milo_")

	RequestIpl("xm_x17dlc_int_placement_interior_30_v_apart_midspaz_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_31_v_studio_lo_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_32_v_garagem_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_33_x17dlc_int_02_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_34_x17dlc_int_lab_milo_")
	RequestIpl("xm_x17dlc_int_placement_interior_35_x17dlc_int_tun_entry_milo_")

	RequestIpl("xm_x17dlc_int_placement_strm_0")
	RequestIpl("xm_bunkerentrance_door")
	RequestIpl("xm_hatch_01_cutscene")
	RequestIpl("xm_hatch_02_cutscene")
	RequestIpl("xm_hatch_03_cutscene")
	RequestIpl("xm_hatch_04_cutscene")
	RequestIpl("xm_hatch_06_cutscene")
	RequestIpl("xm_hatch_07_cutscene")
	RequestIpl("xm_hatch_08_cutscene")
	RequestIpl("xm_hatch_09_cutscene")
	RequestIpl("xm_hatch_10_cutscene")
	RequestIpl("xm_hatch_closed")
	RequestIpl("xm_hatches_terrain")
	RequestIpl("xm_hatches_terrain_lod")
	RequestIpl("xm_mpchristmasadditions")
	--]]

end)

local xnmark = xnmark or {}
local distance = 50.5999

xnmark.locations = {
	["Doomsday Finale"] = {
		["markin"] = {-360.8825378418, 4826.5556640625, 143.14414978028},
		["markout"] = {1256.2868652344, 4798.3833007812, -39.471000671386},
		["locin"] = {1259.5418701172, 4812.1196289062, -39.77448272705, 344.82873535156},
		["locout"] = {-353.65161132812, 4815.8237304688, 142.7413635254},
	},
	["Doomsday Silo"] = {
		["markin"] = {598.3062133789, 5556.9243164062, -716.76141357422}, -- Not Used
		["markout"] = {369.55322265625, 6319.6455078125, -159.92749023438},
		["locin"] = {369.46231079102, 6319.7626953125, -659.92739868164}, -- Not Used
		["locout"] = {602.27032470704, 5546.9267578125, 716.38928222656, 246.04162597656},
	},
	["Doomsday Facility"] = {
		["markin"] = {1286.9239501954, 2845.8833007812, 49.394256591796},
		["markout"] = {489.0622253418, 4785.3623046875, -58.929149627686},
		["locin"] = {483.2006225586, 4810.5405273438, -58.919288635254, 18.04705619812},
		["locout"] = {1267.4091796875, 2830.9741210938, 48.444499969482, 128.1668395996},
	},
	["IAA Facility"] = {
		["markin"] = {2049.8181152344, 2949.5847167968, 47.735733032226},
		["markout"] = {2155.0627441406, 2921.0417480468, -61.902416229248},
		["locin"] = {2151.1369628906, 2921.3303222656, -61.901874542236, 85.827827453614},
		["locout"] = {2053.8020019532, 2953.4047851562, 47.664855957032, 354.8461303711},
	},
	["IAA Server"] = {
		["markin"] = {2477.6774902344, -402.14556884766, 94.817413330078},
		["markout"] = {2154.7639160156, 2921.0678710938, -81.075424194336},
		["locin"] = {2158.1184082032, 2920.9382324218, -81.075386047364, 270.48007202148},
		["locout"] = {2482.9174804688, -405.25631713868, 93.735389709472, 318.76651000976},
	},
	["Doomsday Sub"] = {
		["markin"] = {493.83395385742, -3222.7514648438, 10.49820137024},
		["markout"] = {514.42980957032, 4888.4028320312, -62.589431762696},
		["locin"] = {514.29266357422, 4885.8706054688, -62.589862823486, 180.25909423828},
		["locout"] = {496.30267333984, -3222.6359863282, 6.0695104599, 270.0},
	},
	["weed check"] = {
		["markin"] = {1190.4223632812,-3329.8059082032,5.6322560310364},
		["markout"] = {1065.07, -3181.06, -39.16},
		["locin"] = {1065.37, -3183.66, -39.16, 97.42},
		["locout"] = {1190.76, -3333.04, 5.86, 175.3},
	},
	--[[["blanquear check"] = {
		["markin"] = {639.78234863282,2773.1804199218,42.025310516358},
		["markout"] = {1116.91, -3193.53, -40.39},
		["locin"] = {1118.683, -3193.319, -40.391,221.29},
		["locout"] = {640.22, 2776.59, 41.96},
	},]]--
	["meth check"] = {
		["markin"] = {910.54754638672,-1065.3074951172,37.943222045898},
		["markout"] = {997.91, -3202.18, -36.39},
		["locin"] = {996.8969116211,-3200.6459960938,-36.39372253418,308.97},
		["locout"] = {910.17, -1066.91,37.94,173.79},
	},
	["coke check"] = {
		["markin"] = {387.51754760742,3584.7612304688,33.29222869873},
		["markout"] = {1087.01, -3188.53, -38.99},
		["locin"] = {1088.803, -3188.257, -38.993,178.09},
		["locout"] = {388.22, 3588.12, 33.29},
	},
	["motero check"] = {
		["markin"] = {964.48321533204,-1027.0417480468,40.847507476806},
		["markout"] = {997.93, -3163.54, -38.91},
		["locin"] = {996.97509765625,-3157.9213867188,-38.907146453858,273.4},
		["locout"] = {966.97, -1027.44, 40.85,260.81 },
	},
	--[[["Maze Tower"] = {
		["markin"] = {-68.22,-799.19,44.23},
		["markout"] = {-77.15, -829.82, 243.39},
		["locin"] = {-76.31, -826.86, 243.39, 67.48 },
		["locout"] = {-65.37, -801.01, 44.23, 329.55},
	},]]--
	["Arcadius Business Center"] = {
		["markin"] = {-156.94, -606.43,48.24}, 
		["markout"] = {-141.32, -617.33, 168.82},
		["locin"] = {-141.1987, -620.913, 168.8205,272.08},
		["locout"] = {-155.11, -608.79, 48.24, 127.6},
	},
	["Warehouse Vehicle Davis"] = {
		["markin"] = {-70.74, -1821.85,26.94}, 
		["markout"] = {971.12, -2989.75, -39.65},
		["locin"] = {1003.08,-2997.59, -39.65, 94.4},
		["locout"] = {-84.67,-1793.62, 28.39, 321.8},
	},
	["Red Dead Desert"] = {
		["markin"] = {-1011.86,  -2461.55,20.17},
		["markout"] = {6623.86, -806.6, 23.58},
		["locin"] = {6619.13, -810.88, 23.58, 130.2},
		["locout"] = {-1012.18, -2464.79, 20.17, 166.03},
	},
	["Gunrunning Bunker"] = {
		["markin"] = {-3029.12,  3334.18,10.06},
		["markout"] = {889.39, -3237.69, -98.28}, 
		["locin"] = {892.6384, -3245.8664, -98.2645}, 
		["locout"] = {-3025.45, 3335.02, 10.09,267.57},
	},
	["bikerclubhouse1"] = {
		["markin"] = {-60.35, 6442.31,31.49},
		["markout"] =  {1105.38, -3165.64,-37.52},
		["locin"] = {1110.75, -3165.2,-37.52}, 
		["locout"] = {-65.11, 6446.95, 31.8},
	},
	["humane labs entry"] = {
		["markin"] = {3623.61,3754.3, 28.52},
		["markout"] =  {3626.4, 3745.16, 28.69},
		["locin"] = {3619.29, 3749.34, 28.69, 136.9}, 
		["locout"] = {3629.42, 3750.01, 28.52, 317.61}, 
	},
	["humane labs level 2"] = {
		["markin"] = {3540.96, 3676.64, 28.12},
		["markout"] =  {3540.78, 3676.56, 20.99},
		["locin"] = {3540.38, 3674.28, 20.99, 165.81}, 
		["locout"] = {3540.39, 3674.46, 28.12,161.94}, 
	},
	["Arena Wars"] = {
		["markin"] = {-238.67, -2040.2, 27.76},
		["markout"] =  {2719.12, -3705.15, 140.0},
		["locin"] = {2825.24, -3703.42, 140.0,89.53}, 
		["locout"] = {-246.94, -2033.65, 29.95,224.82}, 
	},
	["Bank Vault"] = {
		["markin"] = {257.45, 223.99, 101.88},
		["markout"] =  {10000.0,10000.0,10000.0},
		["locin"] = {252.66, 221.89, 101.68,160.11}, 
		["locout"] = {10000.0,10000.0,11000.0}, 
	},		
	--[[
		["FIB Office"] = {
		["markin"] = {136.12, -761.53, 45.75},
		["markout"] =  {136.27, -761.23, 234.15 },
		["locin"] = {135.81, -762.59, 234.15, 157.25}, 
		["locout"] = {138.98, -763.24, 45.75,155.8 }, 
		
	},
	]]--
	
}

--{ 135.81, -762.59, 234.15, 157.25 }, --locin
--{ 136.27, -761.23, 234.15 }, --markout
--{ 177.08, -728.91, 39.4, 246.72 }, --locout
--{ 176.0, -728.69, 39.4, 426.75 }, --markin

function TeleportIntoInterior(locationdata, ent)
	local x,y,z,h = table.unpack(locationdata)
	DoScreenFadeOut(1000)
	while IsScreenFadingOut() do Citizen.Wait(0) end
	NetworkFadeOutEntity(GetPlayerPed(-1), true, false)
	Wait(1000)
	SetEntityCoords(GetPlayerPed(-1), x, y, z)
	SetEntityHeading(GetPlayerPed(-1), h)
	NetworkFadeInEntity(GetPlayerPed(-1), 0)
	Wait(1000)
	FreezeEntityPosition(PlayerPedId(), false)
	SetGameplayCamRelativeHeading(0.0)
	DoScreenFadeIn(1000)
	while IsScreenFadingIn() do Citizen.Wait(0)	end
end

function TeleportIntoInteriorVehicle(locationdata, ent)
	local x,y,z,h = table.unpack(locationdata)
	DoScreenFadeOut(1000)
	while IsScreenFadingOut() do Citizen.Wait(0) end
	NetworkFadeOutEntity(GetPlayerPed(-1), true, false)
	Wait(1000)
	SetEntityCoords(GetVehiclePedIsIn(PlayerPedId(), false), x, y, z)
	SetEntityHeading(GetVehiclePedIsIn(PlayerPedId(), false), h)
	NetworkFadeInEntity(GetPlayerPed(-1), 0)
	Wait(1000)
	FreezeEntityPosition(GetVehiclePedIsIn(PlayerPedId(), false), false)
	SetGameplayCamRelativeHeading(0.0)
	DoScreenFadeIn(1000)
	while IsScreenFadingIn() do Citizen.Wait(0)	end
end

function SpawnFacility()
	interiorID = GetInteriorAtCoords(345.0041, 4842.001, -59.9997) --GetInteriorAtCoordsWithType(345.0041, 4842.001, -59.9997, "xm_x17dlc_int_02")
	
	if IsValidInterior(interiorID) then
		--EnableInteriorProp(interiorID, "set_int_02_decal_01")
		--EnableInteriorProp(interiorID, "set_int_02_lounge1")
		--EnableInteriorProp(interiorID, "set_int_02_cannon")
		--EnableInteriorProp(interiorID, "set_int_02_clutter1")
		--EnableInteriorProp(interiorID, "set_int_02_crewemblem")	
		--EnableInteriorProp(interiorID, "set_int_02_shell")
		--EnableInteriorProp(interiorID, "set_int_02_security")
		--EnableInteriorProp(interiorID, "set_int_02_sleep")
		--EnableInteriorProp(interiorID, "set_int_02_trophy1")
		--EnableInteriorProp(interiorID, "set_int_02_paramedic_complete")
		--EnableInteriorProp(interiorID, "set_Int_02_outfit_paramedic")
		--EnableInteriorProp(interiorID, "set_Int_02_outfit_serverfarm")
		--SetInteriorPropColor(interiorID, "set_int_02_decal_01", 1)
		--SetInteriorPropColor(interiorID, "set_int_02_lounge1", 1)
		--SetInteriorPropColor(interiorID, "set_int_02_cannon", 1)
		--SetInteriorPropColor(interiorID, "set_int_02_clutter1", 1)
		--SetInteriorPropColor(interiorID, "set_int_02_shell", 1)
		--SetInteriorPropColor(interiorID, "set_int_02_security", 1)
		--SetInteriorPropColor(interiorID, "set_int_02_sleep", 1)
		--SetInteriorPropColor(interiorID, "set_int_02_trophy1", 1)
		--SetInteriorPropColor(interiorID, "set_int_02_paramedic_complete", 1)
		--SetInteriorPropColor(interiorID, "set_Int_02_outfit_paramedic", 1)  
		--SetInteriorPropColor(interiorID, "set_Int_02_outfit_serverfarm", 1)
		--RefreshInterior(interiorID)
	end	
end

function DespawnFacility()
	interiorID = GetInteriorAtCoords(345.0041, 4842.001, -59.9997) --GetInteriorAtCoordsWithType(345.0041, 4842.001, -59.9997, "xm_x17dlc_int_02")
	
	--DisableInteriorProp(interiorID,  "set_int_02_decal_01")
	--DisableInteriorProp(interiorID,  "set_int_02_lounge1")
	--DisableInteriorProp(interiorID,  "set_int_02_cannon")
	--DisableInteriorProp(interiorID,  "set_int_02_clutter1")
	--DisableInteriorProp(interiorID,  "set_int_02_crewemblem")
	--DisableInteriorProp(interiorID,  "set_int_02_shell")
	--DisableInteriorProp(interiorID,  "set_int_02_security")
	--DisableInteriorProp(interiorID,  "set_int_02_sleep")
	--DisableInteriorProp(interiorID,  "set_int_02_trophy1")
	--DisableInteriorProp(interiorID,  "set_int_02_paramedic_complete")
	--DisableInteriorProp(interiorID,  "Set_Int_02_outfit_paramedic")
	--DisableInteriorProp(interiorID,  "Set_Int_02_outfit_serverfarm")
end


local doneblips = false --GHK
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if not IsEntityDead(PlayerPedId(-1)) then
			for k,v in pairs(xnmark.locations) do
			
				local ix,iy,iz = table.unpack(v["markin"])
				local ox,oy,oz = table.unpack(v["markout"])
				
		
		--GHK CREATE BLIPS
	if(not doneblips) then 
		local idp = 50
		v.blip = AddBlipForCoord(ix, iy, iz)
		  SetBlipSprite(v.blip, idp)
		 -- SetBlipDisplay(v.blip, 4)
		  SetBlipScale(v.blip, 0.7)
		 -- SetBlipDisplay(v.blip, 0.5)
		  --SetBlipColour(v.blip, 3)
		  SetBlipAsShortRange(v.blip, true)
		  BeginTextCommandSetBlipName("STRING")
		  AddTextComponentString("Interior")
		  EndTextCommandSetBlipName(v.blip)	
		idp = idp +1	  --GHK
	end 
				
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), ix, iy, iz, true) < 50.5999 then -- Outside Marker
					DrawMarker(2, ix,iy,iz, 0.0, 0.0, 0.0, 180.0, 0.0, 0.0, 0.75, 0.75, 0.75, 255, 255, 0, 100, false, true, 2, false, false, false, false)
					if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), ix, iy, iz, true) < 1.0 then
						if k == "Doomsday Facility" then
							if IsPedInVehicle(PlayerPedId(), GetVehiclePedIsIn(PlayerPedId(), false), false) then
								FreezeEntityPosition(GetVehiclePedIsIn(PlayerPedId(), false), true)
								TeleportIntoInteriorVehicle(v["locin"], false)
								SpawnFacility()
							else
								FreezeEntityPosition(PlayerPedId(), true)
								--SpawnFacility()
								--TeleportIntoInterior(v["locin"], false)
								
								TeleportIntoInterior(v["locin"], false)	
								SpawnFacility()
							end
						elseif k == "Doomsday Finale" then
							if IsPedInVehicle(PlayerPedId(), GetVehiclePedIsIn(PlayerPedId(), false), false) then
								FreezeEntityPosition(GetVehiclePedIsIn(PlayerPedId(), false), true)
								TeleportIntoInteriorVehicle(v["locin"], false)
							else
								FreezeEntityPosition(PlayerPedId(), true)
								TeleportIntoInterior(v["locin"], false)
							end
						elseif k == "Red Dead Desert" then
							if IsPedInVehicle(PlayerPedId(), GetVehiclePedIsIn(PlayerPedId(), false), false) then
								FreezeEntityPosition(GetVehiclePedIsIn(PlayerPedId(), false), true)
								TeleportIntoInteriorVehicle(v["locin"], false)
							else
								FreezeEntityPosition(PlayerPedId(), true)
								TeleportIntoInterior(v["locin"], false)
							end							
							
						else		
							FreezeEntityPosition(PlayerPedId(), true)
							TeleportIntoInterior(v["locin"], false)
						end
					end
				end
				
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), ox, oy, oz, true) < 50.5999 then -- Inside Marker
					DrawMarker(2, ox, oy, oz, 0.0, 0.0, 0.0, 180.0, 0.0, 0.0, 0.75, 0.75, 0.75, 255, 255, 0, 100, false, true, 2, false, false, false, false)
					if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), ox, oy, oz, true) < 1.0 then
						if k == "Doomsday Facility" then
							if IsPedInVehicle(PlayerPedId(), GetVehiclePedIsIn(PlayerPedId(), false), false) then
								FreezeEntityPosition(GetVehiclePedIsIn(PlayerPedId(), false), true)
								TeleportIntoInteriorVehicle(v["locout"], false)
								DespawnFacility()
							else
								FreezeEntityPosition(PlayerPedId(), true)
								TeleportIntoInterior(v["locout"], false)
								DespawnFacility()
							end
						elseif k == "Doomsday Finale" then
							if IsPedInVehicle(PlayerPedId(), GetVehiclePedIsIn(PlayerPedId(), false), false) then
								FreezeEntityPosition(GetVehiclePedIsIn(PlayerPedId(), false), true)
								TeleportIntoInteriorVehicle(v["locout"], false)
							else
								FreezeEntityPosition(PlayerPedId(), true)
								TeleportIntoInterior(v["locout"], false)
							end
						elseif k == "Red Dead Desert" then
							if IsPedInVehicle(PlayerPedId(), GetVehiclePedIsIn(PlayerPedId(), false), false) then
								FreezeEntityPosition(GetVehiclePedIsIn(PlayerPedId(), false), true)
								TeleportIntoInteriorVehicle(v["locout"], false)
							else
								FreezeEntityPosition(PlayerPedId(), true)
								TeleportIntoInterior(v["locout"], false)
							end							
							
						else
							FreezeEntityPosition(PlayerPedId(), true)
							TeleportIntoInterior(v["locout"], false)
						end
					end
				end
				
			end
		end
		doneblips=true --GHK
	end
end)