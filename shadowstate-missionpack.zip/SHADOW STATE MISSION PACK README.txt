SHADOW STATE MISSION PACK README
********************************
All 12 missions have been incorporated in the main Missions.lua now with the other missions. Mission30->33 and Missions35->42
These missions are mainly in DLC areas and so require an IPL loader and teleportation script. 
See below for info on the supporting resources for those missions. 
See the main README.txt as well that has more information on how to remove missions from
Missions.lua

It requires:
 1.'fivem-ipl' resource by Hawaii_Beach (included)
 https://forum.fivem.net/t/release-fivem-ipl/115816
 2. 'doombunkers' ipl & teleport resource (included) which was 
 based on work shared by Smallo here:
 https://forum.fivem.net/t/dev-doomsday-smugglers-run-interiors-props-ipls-teleport/92124
 
 
 Installation: 
 1.Swap in the missions.lua file for the one already in the mrp-missions-xxx resource. 
 2.install the fivem-ipl and doombunkers via the server.cfg as you would any other resource.
 3. If you have fivem-ipl or another ipl resource already installed, or another DLC teleport resource, 
 you *may* not need step 2. I cant remember if I changed anything in the default fivem-ipl, so if you 
 have problems accessing areas/not seeing teleporters, check what is different. 
 
 Supporting Resource NOTES: the 'doombunkers' teleport resource has a teleporter at the stadium which goes to here:
 https://forum.fivem.net/t/release-arena-war-dlc-arena-ipl-location/234585/26
 and a teleporter at the airport which goes to Red Dead Island:
 https://github.com/KSA01/Red-Dead-Desert
 Download and install those to get all teleporters working, or remove the teleporters.
 
 N. Yankton is turned off in the fivem-ipl since it floats just above the aircraft carrier which is used in a mission. 
 

*Meaningless Background Plot*
Not far in the future of San Andreas, a typical dsytopian scenario of where greed and fear lead to. Sort of a mixture of Blade-Runner/Deus Ex. 
There is a lot of chaos and secrets, where the confluence and privatization of burgeoning technologies of AI, bio-nano, advanced em tech and 
who knows what, is being utilized to gain control of San Andreas. It’s your job to save San Andreas! The tech has already been partly deployed 
and is able to influence/control the general population who are well armed now and can be made to fight against you as well.


